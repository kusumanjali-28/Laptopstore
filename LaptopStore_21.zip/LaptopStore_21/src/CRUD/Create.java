package CRUD;

import Main_Connection.*;
import laptop.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class Create extends Abstract_Crud {
    public static void createLaptop(Laptop lp) {
        List<Laptop> list = GetLaptop.getLaptop(lp.getId());
        Connection con = ConnectionFactory.getConnection();
        if (list.isEmpty()) {
            final String SQL = "insert into laptop values(?,?,?,?)";
            try (PreparedStatement stm = con.prepareStatement(SQL)) {
                stm.setString(1, lp.getId());
                stm.setString(2, lp.getName());
                stm.setInt(3, lp.getPrice());
                stm.setString(4, lp.getAvailability());
                stm.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else
            Update.updateLaptop(lp); // Updates laptop if already exists.
    }
}