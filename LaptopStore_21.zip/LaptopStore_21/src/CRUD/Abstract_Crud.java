package CRUD;

import java.util.List;
import laptop.*;
import Customer.*;
import Main_Connection.ConnectionFactory;

import java.sql.*;

abstract public class Abstract_Crud {
    // This abstract class contains common methods.
    public static void rows(PreparedStatement stm) throws SQLException {
        int i = stm.executeUpdate();
        if (i > 0)
            System.out.println(" number of rows affected are :" + i);
        else
            System.out.println("No rows Found");
    }

    // Prints laptops from result set
    public static void printlp(List<Laptop> a) {
        if (a.isEmpty() == true)
            System.out.println("No Laptops Found");
        else {
            System.out.println(
                    "ID   |  NAME \t  |    PRICE   \t| AVAILABILITY\n-----------------------------------------------");
            a.forEach(System.out::println);
        }
    }

    // Prints customer details from result set.
    public static void printcs(List<Customer> a) {
        if (a.isEmpty() == true)
            System.out.println("No Customers Found");
        else {
            System.out.println(
                    "ID   |  NAME \t|  PHN_NO        |  LAPTOP       |   AMOUNT\n-----------------------------------------------------------------");
            a.forEach(System.out::println);
        }
    }

    public static void count(String type) {
        ResultSet rs;
        int count = 0;
        String SQL = null;
        if (type.equals("laptop"))
            SQL = "SELECT COUNT(*) AS rowcount FROM laptop";
        else if (type.equals("customer"))
            SQL = "SELECT COUNT(*) AS rowcount FROM customer";
        Connection con = ConnectionFactory.getConnection();
        try (PreparedStatement stmt = con.prepareStatement(SQL)) {
            rs = stmt.executeQuery();
            rs.next();
            count = rs.getInt("rowcount");
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("Number of rows:" + count);
    }
}
