package CRUD;

import Main_Connection.*;
import laptop.Laptop;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Update extends Abstract_Crud {
    public static void updateLaptop(Laptop lp) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "update laptop set name=?, price=?,availability=? where id=?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(4, lp.getId());
            stm.setString(1, lp.getName());
            stm.setInt(2, lp.getPrice());
            stm.setString(3, lp.getAvailability());
            rows(stm);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteLaptop_id(String id) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "delete from laptop where id = ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, id);
            rows(stm);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteLaptop_name(String name) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "delete from laptop where name= ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, name);
            rows(stm);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void DeleteAll() {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "truncate table laptop;";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            System.out.println("Deleted Succesfully");
        }
    }
}
